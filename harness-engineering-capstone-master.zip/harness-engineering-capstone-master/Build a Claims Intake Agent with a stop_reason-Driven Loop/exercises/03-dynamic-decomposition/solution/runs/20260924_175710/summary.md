# Run summary — 20260924_175710

- Model: `claude-haiku-4-5-20251001`
- Fixtures processed: 8
- Estimated total cost: **$0.1044** USD

| claim_id | outcome | claim_type | severity | turns | clarifications_asked | input_tokens | output_tokens | est_cost_usd | elapsed_s |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| claim_01_kitchen_fire | incomplete | - | - | 2 | 0 | 6276 | 457 | 0.0086 | 4.5 |
| claim_02_stolen_bike | incomplete | - | - | 2 | 0 | 6158 | 455 | 0.0084 | 4.6 |
| claim_03_water_damage | incomplete | - | - | 3 | 0 | 9188 | 432 | 0.0113 | 5.3 |
| claim_04_neighbor_injury | routed | liability | high | 4 | 0 | 14447 | 880 | 0.0188 | 11.4 |
| claim_05_auto_collision | routed | auto | high | 4 | 0 | 14841 | 903 | 0.0194 | 9.2 |
| claim_06_low_confidence_escalation | incomplete | - | - | 2 | 0 | 6189 | 422 | 0.0083 | 5.4 |
| claim_07_tree_falls_on_car | incomplete | - | - | 2 | 0 | 6180 | 417 | 0.0083 | 5.5 |
| claim_08_minor_porch_damage | routed | property_damage | low | 5 | 0 | 17285 | 798 | 0.0213 | 9.2 |
