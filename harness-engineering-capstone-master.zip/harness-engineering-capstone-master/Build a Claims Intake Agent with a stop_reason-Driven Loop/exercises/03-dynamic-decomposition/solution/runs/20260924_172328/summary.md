# Run summary — 20260924_172328

- Model: `claude-haiku-4-5-20251001`
- Fixtures processed: 8
- Estimated total cost: **$0.1280** USD

| claim_id | outcome | claim_type | severity | turns | clarifications_asked | input_tokens | output_tokens | est_cost_usd | elapsed_s |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| claim_01_kitchen_fire | incomplete | - | - | 2 | 0 | 6268 | 444 | 0.0085 | 4.5 |
| claim_02_stolen_bike | incomplete | - | - | 2 | 0 | 6158 | 448 | 0.0084 | 4.1 |
| claim_03_water_damage | routed | property_damage | high | 7 | 1 | 25845 | 1306 | 0.0324 | 16.6 |
| claim_04_neighbor_injury | routed | liability | high | 5 | 0 | 17177 | 863 | 0.0215 | 12.3 |
| claim_05_auto_collision | routed | auto | high | 4 | 0 | 15345 | 1068 | 0.0207 | 10.9 |
| claim_06_low_confidence_escalation | incomplete | - | - | 2 | 0 | 6407 | 522 | 0.009 | 6.2 |
| claim_07_tree_falls_on_car | incomplete | - | - | 2 | 0 | 6305 | 466 | 0.0086 | 5.7 |
| claim_08_minor_porch_damage | routed | property_damage | low | 4 | 0 | 14505 | 874 | 0.0189 | 8.8 |
